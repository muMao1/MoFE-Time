sh ./eval.sh 	/mnt/datasets/ts-benchmark/0-1-0/Benchmark/traffic/traffic.csv $1 256 48 $2 
